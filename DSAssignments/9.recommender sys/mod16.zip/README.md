Build a recommender system with the given data using UBCF.

Description of the data

In this dataset have users on the rows rated the jokes in the columns. The data is formated as an excel file representing a 66336 x 151 matrix with rows as users and columns as jokes.
    
Each rating is from (-10.00 to +10.00) and 99 corresponds to a null rating (user did not rate that joke). 

Note that the ratings are real values ranging from -10.00 to +10.00. 